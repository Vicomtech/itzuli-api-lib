# Itzuli API library

[How to get your api key](https://itzuli.vicomtech.org/api/)
[All available libraries](https://github.com/Vicomtech/itzuli-api-lib)
